spotify <- read.csv("H:/AIUB/Data Mining/Final Project/K means Clustering/spotify.csv")
View(spotify)




character_columns <- sapply(spotify, is.character)
spotify <- spotify[, !character_columns]
print(spotify)




missing_counts <- colSums(is.na(spotify))
print(missing_counts)

summary(spotify)





# Create a subset of numeric features for clustering
numeric_data <- spotify[, c("duration_ms", "year", "popularity", "danceability", "energy", "key", "loudness", "mode", "speechiness", "acousticness", "instrumentalness", "liveness", "valence", "tempo")]


# Set the number of clusters (K)
k <- 3

# Perform K-means clustering
kmeans_result <- kmeans(selected_features, centers = k)

# Extracting results
final_centroids <- kmeans_result$centers
assignments <- kmeans_result$cluster

# Add cluster assignments to the original dataset
spotify$Cluster <- assignments

# Visualize the clusters using a scatter plot
plot(spotify$danceability, spotify$popularity, col = spotify$Cluster, pch = 16,
     main = "K-means Clustering of Spotify Data",
     xlab = "Danceability", ylab = "Popularity")

# Add legend
legend("topright", legend = unique(assignments), col = unique(assignments), pch = 16, title = "Cluster")

# Print the final centroids
cat("Final Centroids:\n", final_centroids, "\n\n")